# #####BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# #####END GPL LICENSE BLOCK #####
# contributed to by meta-androcto (minir code, materials collection)
bl_info = {
	"name": "Install Contrib Addons",
	"author": "meta-androcto",
	"version": (1, 0, 0),
	"blender": (2, 77, 0),
	"location": "File Menu",
	"description": "Install Blender Addons Contrib Files",
	"warning": "Installs into Blender's main folder",
	"wiki_url": "",
	"tracker_url": "",
	"category": "Install"}

import zipfile, urllib.request, os, sys, re
import csv, codecs
import collections
import subprocess
import webbrowser
import bpy
from bpy.props import *

matlib_path = os.path.dirname(__file__)

class UpdateContribAddon(bpy.types.Operator):
	bl_idname = "script.update_contrib_addon"
	bl_label = "Install Blender-Contrib-Addon"
	bl_description = "Downloads, & installs Blender-Contrib-Addons (5 meg)"
	bl_options = {'REGISTER'}
	
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self)
	
	def draw(self, context):
		pass
	
	def execute(self, context):
		response = urllib.request.urlopen("https://github.com/meta-androcto/downloads/raw/master/addons_contrib.zip")
		tempDir = bpy.app.tempdir
		zipPath = os.path.join(tempDir, "addons_contrib.zip")
		addonDir = os.path.dirname(__file__)
		f = open(zipPath, "wb")
		f.write(response.read())
		f.close()
		zf = zipfile.ZipFile(zipPath, "r")
		for f in zf.namelist():
			if not os.path.basename(f):
				pass
			else:
				if ("Install_Contrib_Addons" in f):
					uzf = open(os.path.join(addonDir, os.path.basename(f)), 'wb')
					uzf.write(zf.read(f))
					uzf.close()
		zf.close()
		self.report(type={"INFO"}, message="Please restart Blender updated add-ons")
		return {'FINISHED'}

def menu(self, context):
    self.layout.operator('script.update_contrib_addon', text = "Install Addons", icon='SAVE_COPY')
        
classes = [UpdateContribAddon]
#print(bpy.context.scene)
	
def register():
	for c in classes:
		bpy.utils.register_class(c)
	bpy.types.INFO_MT_file.append(menu)
def unregister():
	for c in classes:
		bpy.utils.unregister_class(c)
	bpy.types.INFO_MT_file.remove(menu)
if __name__ == "__main__":
    register()
