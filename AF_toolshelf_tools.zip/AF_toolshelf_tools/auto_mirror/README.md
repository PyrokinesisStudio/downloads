# blender-EditMeshDrawNearest

![Image](img.jpg)  
<https://www.youtube.com/watch?v=55R7W0NcUpA>
